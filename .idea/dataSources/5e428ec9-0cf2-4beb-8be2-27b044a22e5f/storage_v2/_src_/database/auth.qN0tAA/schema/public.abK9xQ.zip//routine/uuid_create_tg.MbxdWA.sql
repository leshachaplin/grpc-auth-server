create function uuid_create_tg() returns trigger
    language plpgsql
as
$$
BEGIN
    IF tg_op = 'INSERT' THEN
        NEW.UserId = uuid_generate_v4();
        RETURN NEW;
    END IF;
END;
$$;

alter function uuid_create_tg() owner to lesha;

