create function uuid_restore_create_tg() returns trigger
    language plpgsql
as
$$
BEGIN
    IF tg_op = 'INSERT' THEN
        NEW.UuidRestore = uuid_generate_v4();
        RETURN NEW;
    END IF;
END;
$$;

alter function uuid_restore_create_tg() owner to lesha;

