create function hash_update_tg() returns trigger
    language plpgsql
as
$$
BEGIN
    IF tg_op = 'INSERT' OR tg_op = 'UPDATE' THEN
        NEW.password = encode(digest(NEW.password, 'sha256'), 'hex');
        RETURN NEW;
    END IF;
END;
$$;

alter function hash_update_tg() owner to lesha;

